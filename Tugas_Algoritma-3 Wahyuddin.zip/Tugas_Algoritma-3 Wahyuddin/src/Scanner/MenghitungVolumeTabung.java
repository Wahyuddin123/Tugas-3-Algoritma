/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author Wahyuddin
 */
public class MenghitungVolumeTabung {
    public static void main(String[] args){
        Scanner scan =new Scanner(System.in);
        double volume, r, t;
        
        System.out.print("Inputkan nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        System.out.print("Inputkan nilai t =");
        t = Double.valueOf(scan.nextLine());
        
        volume = 3.14*r*r*t;
        System.out.println("Hasil volume tabung ="+volume);
        
        //r=jari-jari
        //t=tinggi
        
}

}