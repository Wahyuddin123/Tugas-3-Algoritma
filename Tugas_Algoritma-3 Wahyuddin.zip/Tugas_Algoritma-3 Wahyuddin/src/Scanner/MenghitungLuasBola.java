/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author Wahyuddin
 */
public class MenghitungLuasBola {
    public static void main(String[] args){
        Scanner scan =new Scanner(System.in);
        double luas, r;
        
        System.out.print("Nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        luas = 4*3.14*r*r;
        System.out.println("Hasil luas bola ="+luas);
        
        //r=jari-jari
                
    }
}
